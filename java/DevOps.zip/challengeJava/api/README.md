# API Challenge - Sistema de Gestão de Veterinários e Tutores

Este projeto é uma API RESTful desenvolvida com Spring Boot, focada na gestão de veterinários, tutores e seus animais.

## Descrição do Projeto
O sistema permite o cadastro e gerenciamento de tutores, veterinários e seus respectivos animais, fornecendo suporte para operações de CRUD e persistência de dados.

## Benefícios para o Negócio
- **Digitalização da Gestão Veterinária:** Automatiza o registro e a consulta de prontuários.
- **Escalabilidade:** Arquitetura baseada em containers permite fácil escalabilidade em nuvem.
- **Agilidade:** Operações de CRUD rápidas facilitam o atendimento em clínicas.

## Desenho Macro da Arquitetura
[Inserir aqui a imagem do desenho da arquitetura - Ferramentas sugeridas: Draw.io ou Visual Paradigm]

## Rotas da API
- `GET /tutor/ping`: Health check.
- `POST /tutor`: Criar Tutor.
- `GET /tutor/{cpf}`: Buscar Tutor por CPF.
- `PUT /tutor/{cpf}/CreateAnimal`: Adicionar Animal.
- `GET /tutor/{cpf}/ReadAnimals`: Listar Animais.
- `POST /veterinarian`: Criar Veterinário.

## Instalação da Solução (How to)

### Pré-requisitos
- Docker e Docker Compose instalados.

### Execução com Docker
1. Clone o repositório.
2. Navegue até a pasta do projeto.
3. Execute o comando:
   ```bash
   docker-compose up -d
   ```

### Dockerfile
```dockerfile
# (Conteúdo do seu Dockerfile)
```

### Docker Compose
```yaml
version: '3.9'
services:
  api:
    build: .
    container_name: clyvovet-api
    ports:
      - "8080:8080"
    depends_on:
      - h2db
  h2db:
    image: oscarfonts/h2
    container_name: clyvovet-h2
    ports:
      - "9090:9090"
      - "81:81"
    volumes:
      - clyvovet-volume:/opt/h2-data
volumes:
  clyvovet-volume:
```

### Script Azure CLI
Consulte o arquivo `provision.sh` na raiz do repositório.
